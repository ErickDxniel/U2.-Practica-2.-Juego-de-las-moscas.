package mx.tecnm.tepic.ladm_u2_ejercicio3

import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.View



class lienzo(p: MainActivity) : View(p) {
    //Tiempo del Cronometro
    var tiempo = 60

    var xSplash = -1000f
    var ySplash = -1000f

    var presionada = false
    var mancha = Imagen(this, xSplash, ySplash, R.drawable.marca)
    var mosca1 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca2 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca3 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca4 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca5 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca6 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca7 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca8 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca9 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca10 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )


    var mosca11 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca12 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca13 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca14 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca15 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca16 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca17 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca18 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca19 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca20 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca21 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca22 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca23 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca24 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca25 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca26 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca27 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca28 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca29 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca30 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca31 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca32 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca33 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca34 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca35 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca36 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca37 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca38 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca39 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca40 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca41 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca42 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca43 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca44 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca45 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca46 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca47 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca48 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca49 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca50 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca51 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca52 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca53 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca54 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca55 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca56 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca57 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca58 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca59 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca60 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca61 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca62 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca63 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca64 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca65 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca66 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca67 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca68 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca69 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca70 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var mosca71 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca72 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca73 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca74 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca75 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca76 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca77 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca78 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca79 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )
    var mosca80 = Imagen(
        this,
        (0..1080).random().toFloat(),
        (0..2000).random().toFloat(),
        R.drawable.mosca
    )

    var puntero: Imagen? = null// No tiene memoria

    var timerActivado = false
    var posX = 50f
    var posY = 1000f
    var puntuacion = 0
    var findeljuego = true

    val timer = object : CountDownTimer(60000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            tiempo--
            invalidate()
        }

        override fun onFinish() {
            findeljuego = true

            if (puntuacion >= 70) {
                AlertDialog.Builder(p)
                    .setTitle("Alcanzaste la putuación maxima | Felicidades")
                    .setMessage("Puntuación: ${puntuacion}")
                    .setPositiveButton("Ok") { d, i -> d.dismiss() }
                    .show()
                //tiempo = 0
            } else {
                AlertDialog.Builder(p)
                    .setTitle("Fin del Juego")
                    .setMessage("Puntuación: ${puntuacion}")
                    .setPositiveButton("Ok") { d, i -> d.dismiss() }
                    .show()

            }//else
        }//onefinish
    }//timer


    override fun onDraw(c: Canvas) {
        super.onDraw(c)

        val p = Paint()

        if (presionada) {
            mancha.pintar(c)
        }//if-Aplastada

        mosca1.pintar(c)
        mosca2.pintar(c)
        mosca3.pintar(c)
        mosca4.pintar(c)
        mosca5.pintar(c)
        mosca6.pintar(c)
        mosca7.pintar(c)
        mosca8.pintar(c)
        mosca9.pintar(c)
        mosca10.pintar(c)

        mosca11.pintar(c)
        mosca12.pintar(c)
        mosca13.pintar(c)
        mosca14.pintar(c)
        mosca15.pintar(c)
        mosca16.pintar(c)
        mosca17.pintar(c)
        mosca18.pintar(c)
        mosca19.pintar(c)
        mosca20.pintar(c)

        mosca21.pintar(c)
        mosca22.pintar(c)
        mosca23.pintar(c)
        mosca24.pintar(c)
        mosca25.pintar(c)
        mosca26.pintar(c)
        mosca27.pintar(c)
        mosca28.pintar(c)
        mosca29.pintar(c)
        mosca30.pintar(c)

        mosca31.pintar(c)
        mosca32.pintar(c)
        mosca33.pintar(c)
        mosca34.pintar(c)
        mosca35.pintar(c)
        mosca36.pintar(c)
        mosca37.pintar(c)
        mosca38.pintar(c)
        mosca39.pintar(c)
        mosca40.pintar(c)

        mosca41.pintar(c)
        mosca42.pintar(c)
        mosca43.pintar(c)
        mosca44.pintar(c)
        mosca45.pintar(c)
        mosca46.pintar(c)
        mosca47.pintar(c)
        mosca48.pintar(c)
        mosca49.pintar(c)
        mosca50.pintar(c)

        mosca51.pintar(c)
        mosca52.pintar(c)
        mosca53.pintar(c)
        mosca54.pintar(c)
        mosca55.pintar(c)
        mosca56.pintar(c)
        mosca57.pintar(c)
        mosca58.pintar(c)
        mosca59.pintar(c)
        mosca60.pintar(c)

        mosca61.pintar(c)
        mosca62.pintar(c)
        mosca63.pintar(c)
        mosca64.pintar(c)
        mosca65.pintar(c)
        mosca66.pintar(c)
        mosca67.pintar(c)
        mosca68.pintar(c)
        mosca69.pintar(c)
        mosca70.pintar(c)

        mosca71.pintar(c)
        mosca72.pintar(c)
        mosca73.pintar(c)
        mosca74.pintar(c)
        mosca75.pintar(c)
        mosca76.pintar(c)
        mosca77.pintar(c)
        mosca78.pintar(c)
        mosca79.pintar(c)
        mosca80.pintar(c)
        //Cronometro
        //contador
        p.textSize = 40f
        p.setColor(Color.BLACK)
        c.drawText("Tiempo restante ${tiempo}", 350f, 50f, p)
        //Contador Moscas
        p.textSize = 100f
        c.drawText(puntuacion.toString(), 950f, 100f, p)


    }

    override fun onTouchEvent(event: MotionEvent): Boolean {

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (timerActivado == false) {

                    timer.start()
                    timerActivado = true

                }//if

                if (mosca1.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca1
                    mosca1.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca2.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca2
                    mosca2.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca3.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca3
                    mosca3.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca4.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca4
                    mosca4.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca5.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca5
                    mosca5.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca6.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca6
                    mosca6.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca7.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca7
                    mosca7.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca8.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca8
                    mosca8.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca9.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca9
                    mosca9.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca10.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca10
                    mosca10.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }

                if (mosca11.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca11
                    mosca11.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca12.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca12
                    mosca12.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca13.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca13
                    mosca13.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca14.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca14
                    mosca14.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca15.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca15
                    mosca15.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca16.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca16
                    mosca16.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca17.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca17
                    mosca17.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca18.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca18
                    mosca18.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca19.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca19
                    mosca19.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca20.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca20
                    mosca20.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca21.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca21
                    mosca21.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca22.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca22
                    mosca22.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca23.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca23
                    mosca23.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca24.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca24
                    mosca24.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca25.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca25
                    mosca25.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca26.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca26
                    mosca26.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca27.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca27
                    mosca27.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca28.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca28
                    mosca28.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca29.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca29
                    mosca29.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca30.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca30
                    mosca30.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca31.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca31
                    mosca31.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca32.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca32
                    mosca32.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca33.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca33
                    mosca33.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca34.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca34
                    mosca34.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca35.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca35
                    mosca35.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca36.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca36
                    mosca36.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca37.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca37
                    mosca37.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca38.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca38
                    mosca38.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca39.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca39
                    mosca39.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca40.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca40
                    mosca40.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca41.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca41
                    mosca41.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca42.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca42
                    mosca42.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca43.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca43
                    mosca43.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca44.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca44
                    mosca44.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca45.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca45
                    mosca45.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca46.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca46
                    mosca46.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca47.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca47
                    mosca47.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca48.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca48
                    mosca48.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca49.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca49
                    mosca49.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca50.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca50
                    mosca50.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca51.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca51
                    mosca51.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca52.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca52
                    mosca52.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca53.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca53
                    mosca53.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca54.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca54
                    mosca54.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca55.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca55
                    mosca55.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca56.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca56
                    mosca56.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca57.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca57
                    mosca57.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca58.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca58
                    mosca58.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca59.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca59
                    mosca59.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca60.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca60
                    mosca60.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca61.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca61
                    mosca61.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca62.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca62
                    mosca62.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca63.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca63
                    mosca63.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca64.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca64
                    mosca64.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca65.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca65
                    mosca65.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca66.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca66
                    mosca66.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca67.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca67
                    mosca67.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca68.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca68
                    mosca68.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca69.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca69
                    mosca69.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca70.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca70
                    mosca70.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca71.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca71
                    mosca71.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca72.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca72
                    mosca72.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca73.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca73
                    mosca73.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca74.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca74
                    mosca74.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca75.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca75
                    mosca75.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca76.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca76
                    mosca76.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca77.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca77
                    mosca77.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca78.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca78
                    mosca78.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca79.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca79
                    mosca79.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
                if (mosca80.estaEnArea(event.x, event.y)) {
                    puntuacion = puntuacion + 1
                    puntero = mosca80
                    mosca80.parar(10000, 10000)
                    presionada = true
                    mancha.pintaMarca(Canvas(), Paint(), (event.x), (event.y))
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> {
            }
            MotionEvent.ACTION_UP -> {
                puntero = null
            }
        }
        invalidate()
        return true
    }

    fun animarMoscas() {
        mosca1.movimiento(width, height)
        mosca2.movimiento(width, height)
        mosca3.movimiento(width, height)

        mosca4.movimiento(width, height)
        mosca5.movimiento(width, height)
        mosca6.movimiento(width, height)
        mosca7.movimiento(width, height)
        mosca8.movimiento(width, height)
        mosca9.movimiento(width, height)
        mosca10.movimiento(width, height)

        mosca11.movimiento(width, height)
        mosca12.movimiento(width, height)
        mosca13.movimiento(width, height)
        mosca14.movimiento(width, height)
        mosca15.movimiento(width, height)
        mosca16.movimiento(width, height)
        mosca17.movimiento(width, height)
        mosca18.movimiento(width, height)
        mosca19.movimiento(width, height)
        mosca20.movimiento(width, height)

        mosca21.movimiento(width, height)
        mosca22.movimiento(width, height)
        mosca23.movimiento(width, height)
        mosca24.movimiento(width, height)
        mosca25.movimiento(width, height)
        mosca26.movimiento(width, height)
        mosca27.movimiento(width, height)
        mosca28.movimiento(width, height)
        mosca29.movimiento(width, height)
        mosca30.movimiento(width, height)

        mosca31.movimiento(width, height)
        mosca32.movimiento(width, height)
        mosca33.movimiento(width, height)
        mosca34.movimiento(width, height)
        mosca35.movimiento(width, height)
        mosca36.movimiento(width, height)
        mosca37.movimiento(width, height)
        mosca38.movimiento(width, height)
        mosca39.movimiento(width, height)
        mosca40.movimiento(width, height)

        mosca41.movimiento(width, height)
        mosca42.movimiento(width, height)
        mosca43.movimiento(width, height)
        mosca44.movimiento(width, height)
        mosca45.movimiento(width, height)
        mosca46.movimiento(width, height)
        mosca47.movimiento(width, height)
        mosca48.movimiento(width, height)
        mosca49.movimiento(width, height)
        mosca50.movimiento(width, height)

        mosca51.movimiento(width, height)
        mosca52.movimiento(width, height)
        mosca53.movimiento(width, height)
        mosca54.movimiento(width, height)
        mosca55.movimiento(width, height)
        mosca56.movimiento(width, height)
        mosca57.movimiento(width, height)
        mosca58.movimiento(width, height)
        mosca59.movimiento(width, height)
        mosca60.movimiento(width, height)

        mosca61.movimiento(width, height)
        mosca62.movimiento(width, height)
        mosca63.movimiento(width, height)
        mosca64.movimiento(width, height)
        mosca65.movimiento(width, height)
        mosca66.movimiento(width, height)
        mosca67.movimiento(width, height)
        mosca68.movimiento(width, height)
        mosca69.movimiento(width, height)
        mosca70.movimiento(width, height)

        mosca71.movimiento(width, height)
        mosca72.movimiento(width, height)
        mosca73.movimiento(width, height)
        mosca74.movimiento(width, height)
        mosca75.movimiento(width, height)
        mosca76.movimiento(width, height)
        mosca77.movimiento(width, height)
        mosca78.movimiento(width, height)
        mosca79.movimiento(width, height)
        mosca80.movimiento(width, height)

        invalidate()
    }
}


